<?php

include("conexion.php");
include("diseñoCond.php");

?>