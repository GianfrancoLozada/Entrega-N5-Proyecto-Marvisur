<?php

include("conexion.php");
include("diseñoEnc.php");

?>