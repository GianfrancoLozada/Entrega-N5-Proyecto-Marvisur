<?php

include("conexion.php");
include("consulta2.php");

?>