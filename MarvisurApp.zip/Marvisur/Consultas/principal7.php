<?php

include("conexion.php");
include("consulta7.php");

?>