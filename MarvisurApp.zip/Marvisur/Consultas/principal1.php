<?php

include("conexion.php");
include("consulta1.php");

?>