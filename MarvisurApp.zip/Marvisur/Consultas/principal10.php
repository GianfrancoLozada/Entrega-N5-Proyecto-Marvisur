<?php

include("conexion.php");
include("consulta10.php");

?>