<?php

include("conexion.php");
include("consulta5.php");

?>