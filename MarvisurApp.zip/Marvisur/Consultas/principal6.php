<?php

include("conexion.php");
include("consulta6.php");

?>