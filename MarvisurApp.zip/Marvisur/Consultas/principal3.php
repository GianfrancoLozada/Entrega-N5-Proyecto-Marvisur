<?php

include("conexion.php");
include("consulta3.php");

?>