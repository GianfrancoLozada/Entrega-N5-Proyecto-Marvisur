<?php

include("conexion.php");
include("diseño.php");

?>